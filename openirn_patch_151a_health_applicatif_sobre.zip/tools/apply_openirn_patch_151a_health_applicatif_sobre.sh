#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

echo "[151A] Health applicatif sobre"

python3 - <<'PY'
from pathlib import Path
import re

root = Path.cwd()
main_path = root / "server" / "openirn-api" / "app" / "main.py"
if not main_path.exists():
    raise SystemExit("[ERREUR] server/openirn-api/app/main.py introuvable")

text = main_path.read_text(encoding="utf-8")
replacement = '''@app.get("/health")
def health() -> dict[str, Any]:
    """
    Public, compact health check for monitoring.

    The endpoint exposes stable product-level metadata and a coarse calculated
    tenant count. It deliberately does not expose route inventory, database
    paths, tenant names, users, campaigns, device identifiers or diagnostic
    error details.
    """
    status = "ok"
    tenant_number = 0

    if not DB_PATH.exists():
        status = "degraded"
    else:
        try:
            db_uri = "file:" + urllib.parse.quote(str(DB_PATH), safe="/:") + "?mode=ro"
            with sqlite3.connect(db_uri, uri=True) as con:
                row = con.execute("SELECT COUNT(*) FROM tenants").fetchone()
                tenant_number = int(row[0]) if row and row[0] is not None else 0
        except sqlite3.Error:
            status = "degraded"
            tenant_number = 0

    return {
        "status": status,
        "application": "OpenIRN API",
        "version": APP_VERSION,
        "storage": "sqlite",
        "tenantNumber": tenant_number,
        "authRequired": True,
        "authMode": "server_session_with_role_policy",
        "serverTime": _utc_now().isoformat(),
    }
'''

pattern = re.compile(r'@app\.get\("/health"\)\ndef health\(\) -> dict\[str, Any\]:\n.*?(?=\n\n@app\.)', re.S)
new_text, count = pattern.subn(replacement, text, count=1)
if count != 1:
    raise SystemExit("[ERREUR] Fonction health() introuvable ou déjà trop modifiée")
main_path.write_text(new_text, encoding="utf-8")

api_path = root / "api" / "openapi_sync_draft.yaml"
if api_path.exists():
    api_text = api_path.read_text(encoding="utf-8")
    block = '''  /health:
    get:
      security: []
      summary: Vérifie l’état général du serveur OpenIRN avec une réponse publique sobre.
      responses:
        '200':
          description: État général du serveur OpenIRN.
          content:
            application/json:
              schema:
                type: object
                required:
                  - status
                  - application
                  - version
                  - storage
                  - tenantNumber
                  - authRequired
                  - authMode
                  - serverTime
                properties:
                  status:
                    type: string
                    enum: [ok, degraded]
                    example: ok
                  application:
                    type: string
                    example: OpenIRN API
                  version:
                    type: string
                    example: 0.10.0
                  storage:
                    type: string
                    enum: [sqlite]
                    example: sqlite
                  tenantNumber:
                    type: integer
                    minimum: 0
                    example: 3
                  authRequired:
                    type: boolean
                    example: true
                  authMode:
                    type: string
                    example: server_session_with_role_policy
                  serverTime:
                    type: string
                    format: date-time
                    example: '2026-07-02T18:00:00+00:00'
'''
    api_text, api_count = re.subn(r'  /health:\n.*?(?=  /sync/push:)', block, api_text, flags=re.S)
    if api_count:
        api_path.write_text(api_text, encoding="utf-8")
PY

python3 -m py_compile server/openirn-api/app/main.py

python3 - <<'PY'
from pathlib import Path
import re
text = (Path("server/openirn-api/app/main.py")).read_text(encoding="utf-8")
match = re.search(r'@app\.get\("/health"\)\ndef health\(\) -> dict\[str, Any\]:\n(?P<body>.*?)(?=\n\n@app\.)', text, re.S)
if not match:
    raise SystemExit("[ERREUR] health() introuvable après patch")
body = match.group("body")
return_match = re.search(r'return \{(?P<returned>.*?)\n    \}', body, re.S)
returned = return_match.group("returned") if return_match else body
for forbidden in ('"endpoints"', '"database"', 'cluster_name', 'number_of_nodes', 'active_services'):
    if forbidden in returned:
        raise SystemExit(f"[ERREUR] /health expose encore un champ trop bavard : {forbidden}")
for required in ('"tenantNumber"', '"authRequired"', '"authMode"', '"serverTime"'):
    if required not in returned:
        raise SystemExit(f"[ERREUR] champ attendu absent de /health : {required}")
PY

echo "[151A] OK — /health est compact, calculé et sans inventaire des routes."
