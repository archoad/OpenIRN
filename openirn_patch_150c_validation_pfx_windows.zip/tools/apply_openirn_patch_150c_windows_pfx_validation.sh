#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"
echo "[150C] Validation certificat Windows PFX dans le workflow release"
if [[ ! -f .github/workflows/release.yml ]]; then
  echo "[ERREUR] .github/workflows/release.yml introuvable" >&2
  exit 1
fi
grep -q "Import and validate Windows signing certificate" .github/workflows/release.yml
grep -q "X509Certificate2" .github/workflows/release.yml
grep -q "WINDOWS_CERTIFICATE_PASSWORD.Trim" .github/workflows/release.yml
echo "[150C] OK"
