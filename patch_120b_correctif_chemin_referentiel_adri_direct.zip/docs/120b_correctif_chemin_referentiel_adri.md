# Patch 120B — Correctif chemin référentiel officiel aDRI

## Problème corrigé

Le dépôt officiel aDRI ne contient plus le référentiel dans le chemin historique :

```text
Grille d'évaluation IRN (FR)/xlsx
```

Le chemin actuel publié dans le dépôt GitLab est :

```text
Référentiel d'évaluation IRN (FR)/V1
```

Le fichier détecté est désormais de la forme :

```text
Référentiel IRN_v1.1.xlsx
```

au lieu du motif historique :

```text
Questionnaire_IRN_v*.xlsx
```

## Changements

- chemin par défaut corrigé côté serveur ;
- recherche récursive dans l'arborescence GitLab ;
- prise en charge des deux formats de nommage :
  - `Questionnaire_IRN_v*.xlsx` ;
  - `Référentiel IRN_v*.xlsx` ;
- fallback automatique sur les chemins connus ;
- message d'erreur plus clair si le chemin configuré via `OPENIRN_ADRI_TREE_PATH` est introuvable.

## Fichier modifié

```text
server/openirn-api/app/main.py
```

## Validation

```bash
cd server/openirn-api
python3 -m py_compile app/main.py
```

Puis redémarrer l'API OpenIRN.
